import React from "react";
import BtnToolBarTemplateDanger from "../Atomo/BtnToolBarTemplateDanger";
export default function RightToolBarTemplate({ openNew, nameBtn }) {
  return (
    <>
      <BtnToolBarTemplateDanger openNew={openNew} nameBtn={nameBtn} />
    </>
  );
}
