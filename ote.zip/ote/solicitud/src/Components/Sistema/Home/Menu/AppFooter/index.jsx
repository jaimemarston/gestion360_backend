import React from "react";

export default function AppFooter() {
  return (
    <div className="layout-footer">
      <span className="font-medium ml-2">Facturacion</span>
    </div>
  );
}
