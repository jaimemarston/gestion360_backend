
export default function Facturacion() {

  return (
    <div className="grid  crud-demo">
      <div className="col-12">
        <div className="card">
        
        </div>
      </div>
    </div>
  );
}
