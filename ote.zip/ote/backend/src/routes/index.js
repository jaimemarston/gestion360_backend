import userRoutes from './user.routes.js';
import authLogin from './auth.routes.js';
import solicitudRoutes from './solicitud.routes.js';
import solicitudProductoRoutes from './solicitudProducto.routes.js';

export { userRoutes, authLogin, solicitudProductoRoutes, solicitudRoutes };
